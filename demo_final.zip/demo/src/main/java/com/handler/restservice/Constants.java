package com.handler.restservice;

public final class Constants {

    public static final String USER_TASKS_FILETR = "https://cognizant-ipm.bpm.ibmcloud.com/bpm/dev/rest/bpm/wle/v1/tasks?calcStats=true";
    public static final String ALL_USER_TASKS = "https://cognizant-ipm.bpm.ibmcloud.com/bpm/dev/rest/bpm/wle/v1/service/4e36c23d-dca6-474a-9134-b4fe6145d836?action=start&accept=application/json";
    public static final String CURRENT_USER_DETAILS = "https://cognizant-ipm.bpm.ibmcloud.com/bpm/dev/rest/bpm/wle/v1/user/current?includeInternalMemberships=false&includeEditableUserPreferences=false&parts=all&accept=application/json";
    public static final String START_ONBOARDING_PROCESS = "https://cognizant-ipm.bpm.ibmcloud.com/bpm/dev/rest/bpm/wle/v1/process?action=start&bpdId=25.36b0ce4e-1148-4b2e-96c5-e682a7093426&branchId=2063.a7bcf1dd-6064-46b6-8ae4-efab935eabc6&parts=all";
    public static final String CLAIM_TASK = "https://cognizant-ipm.bpm.ibmcloud.com/bpm/dev/rest/bpm/wle/v1/task/{taskId}?action=assign&toMe=true&parts=all";
    public static final String COMPLETE_TASK = "https://cognizant-ipm.bpm.ibmcloud.com/bpm/dev/rest/bpm/wle/v1/task/{taskId}?action=complete&params=";
    public static final String REASSIGN_TASK = "https://cognizant-ipm.bpm.ibmcloud.com/bpm/dev/rest/bpm/wle/v1/task/{taskId}?action=assign&toUser={userId}&parts=all";
    public static final String TASK_DETAILS = "https://cognizant-ipm.bpm.ibmcloud.com/bpm/dev/rest/bpm/wle/v1/process/{instanceId}?parts=all";
    
}


