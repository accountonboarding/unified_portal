package com.handler.restservice;

public class ApplicationDetails {
    private String appName;
    private String description;
    public String getAppName() {
           return appName;
    }
    public void setAppName(String appName) {
           this.appName = appName;
    }
    public String getDescription() {
           return description;
    }
    public void setDescription(String description) {
           this.description = description;
    }
    public ApplicationDetails(String appName, String description) {
           super();
           this.appName = appName;
           this.description = description;
    }
    public ApplicationDetails() {
           
    }
    
}

