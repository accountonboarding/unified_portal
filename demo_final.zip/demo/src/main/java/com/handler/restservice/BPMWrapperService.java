package com.handler.restservice;

import java.net.URI;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.google.gson.JsonArray;
import com.google.gson.JsonNull;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

@Service
public class BPMWrapperService {
	
	
	
	   

                HttpHeaders createHeaders(String authorization) {
                                return new HttpHeaders() {
                                                {
                                                                set("Authorization", authorization);

                                                }
                                };
                }

                public ResponseEntity<String> getUserDetails(@RequestHeader HttpHeaders headers) {
                                ResponseEntity<String> userDetails = null;

                                final String authorization = headers.get("Authorization").get(0);
                                String uri = Constants.CURRENT_USER_DETAILS;
                                RestTemplate restTemplate = new RestTemplate();
                                System.out.println("Getting User Data from BPM .... ");

                                userDetails = restTemplate.exchange(uri, HttpMethod.GET, new HttpEntity<String>(createHeaders(authorization)),
                                                                String.class);

                                System.out.println("BPM call successful!!");
                                return userDetails;

                }
                


                public ResponseEntity<String> getBPMTasksForProcessApp(HttpHeaders headers, String processApp,
                                                Optional<String> interaction) {
                                ResponseEntity<String> taskDetails = null;

                                System.out.println("header = "+headers);
                                final String authorization = headers.get("Authorization").get(0);//"Basic YzAzODczMzpLb2xrYXRhNw==";//
                                String uri = Constants.USER_TASKS_FILETR;
                                RestTemplate restTemplate = new RestTemplate();
                                System.out.println("Getting Task Data from BPM .... ");

                                HttpHeaders localHeaders = new HttpHeaders();

                                localHeaders.add("Authorization", authorization);
                                localHeaders.add("Content-Type", "application/json");

                                if (!interaction.isPresent()) {
                                                interaction = Optional.of("claimed_and_available");
                                }

                                String payloadforBPM = "{\r\n" + "  \"organization\": \"byTask\",\r\n" + "             \"shared\": false,\r\n"
                                                                + "           \"teams\": [],\r\n" + "         \"sort\": [{\r\n" + "                                              \"field\": \"taskDueDate\",\r\n"
                                                                + "                                           \"order\": \"ASC\"\r\n" + "                                }\r\n" + "                ],\r\n" + "           \"conditions\": [{\r\n"
                                                                + "                                           \"field\": \"instanceProcessApp\",\r\n" + "                                    \"operator\": \"Equals\",\r\n"
                                                                + "                                           \"value\": \"" + processApp + "\"\r\n" + "                      }\r\n" + "                ],\r\n"
                                                                + "           \"fields\": [\"taskSubject\", \"instanceName\", \"taskStatus\", \"taskPriority\", \"assignedToRoleDisplayName\", \"assignedToUser\", \"taskClosedDate\", \"taskDueDate\", \"taskIsAtRisk\"],\r\n"
                                                                + "           \"aliases\": [],\r\n" + "        \"interaction\": \"" + interaction.get() + "\",\r\n"
                                                                + "           \"size\": 10000\r\n" + "}";
                                HttpEntity<String> request = new HttpEntity<String>(payloadforBPM, localHeaders);

                                taskDetails = restTemplate.exchange(uri, HttpMethod.PUT, request, String.class);
                                System.out.println("BPM call output ====>>>> " + taskDetails.getBody());
                                System.out.println("BPM call successful!!");

                                HttpHeaders tempHeaders = taskDetails.getHeaders();
                                HttpStatus tempStatus = taskDetails.getStatusCode();
                                String tempBody = taskDetails.getBody();
                                JsonObject jsonObject = new JsonParser().parse(tempBody).getAsJsonObject();
                                jsonObject.getAsJsonObject("data").remove("attributeInfo");

                                JsonArray items = jsonObject.getAsJsonObject("data").getAsJsonArray("items");

                                JsonArray newItems = new JsonArray();

                                for (int i = 0; i < items.size(); i++) {
                                                JsonObject taskItem = items.get(i).getAsJsonObject();
                                                JsonObject newTask = new JsonObject();

                                                newTask.add("taskId", taskItem.get("TASK.TKIID"));
                                                newTask.add("instanceId", taskItem.get("PROCESS_INSTANCE.PIID"));
                                                newTask.add("taskStatus", taskItem.get("STATUS"));
                                                newTask.add("instanceName", taskItem.get("PI_NAME"));
                                                newTask.add("taskSubject", taskItem.get("TAD_DISPLAY_NAME"));
                                                newTask.add("assignedToRole",
                                                                                !taskItem.get("ASSIGNED_TO_ROLE_DISPLAY_NAME").isJsonNull()
                                                                                                                ? taskItem.get("ASSIGNED_TO_ROLE_DISPLAY_NAME")
                                                                                                                : JsonNull.INSTANCE);
                                                newTask.add("assignedToUser",
                                                                                !taskItem.get("OWNER").isJsonNull() ? taskItem.get("OWNER") : JsonNull.INSTANCE);
                                                newTask.add("dueDate", taskItem.get("DUE"));

                                                newItems.add(newTask);

                                }
                                jsonObject.getAsJsonObject("data").add("items", newItems);

                                return new ResponseEntity<>(jsonObject.toString(), tempHeaders, tempStatus);
                }

                public ResponseEntity<String> getAllActiveTasks(HttpHeaders headers) {

                                ResponseEntity<String> taskData = null;

                                final String authorization = headers.get("Authorization").get(0);
                                String uri = Constants.ALL_USER_TASKS;
                                RestTemplate restTemplate = new RestTemplate();
                                System.out.println("Getting Task Data from BPM .... "+authorization);
                                taskData = restTemplate.exchange(uri, HttpMethod.POST, new HttpEntity<String>(createHeaders(authorization)),
                                                                String.class);
                                
                                System.out.println("BPM call successful!!");
                                return taskData;
                }

                public ResponseEntity<String> startOnboardingProcess(HttpHeaders headers, String payload) {

                                ResponseEntity<String> startProcessRes = null;

                                final String authorization = headers.get("Authorization").get(0);
                                
                                //String uri = Constants.START_ONBOARDING_PROCESS  + payload ;
                                String uri = Constants.START_ONBOARDING_PROCESS;
                                URI encodedUri = UriComponentsBuilder.fromUriString(uri).build().encode().toUri();
                                
                                RestTemplate restTemplate = new RestTemplate();
                                System.out.println("Starting BPM process .... ");
                                startProcessRes = restTemplate.exchange(encodedUri, HttpMethod.POST,
                                                                new HttpEntity<String>(createHeaders(authorization)), String.class);

                                System.out.println("BPM call successful!!=="+startProcessRes);
                                return startProcessRes;
                }
                
                
                public ResponseEntity<String>   claimTask(HttpHeaders headers, String taskId) {

                                ResponseEntity<String> startProcessRes = null;

                                final String authorization = headers.get("Authorization").get(0);
                                
                                Map<String, String> pathVar = new HashMap<String, String>();
                                pathVar.put("taskId", taskId);
                                UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(Constants.CLAIM_TASK);
                                URI uri = builder.buildAndExpand(pathVar).toUri();
                                RestTemplate restTemplate = new RestTemplate();
                                System.out.println("Claim task .... ");
                                startProcessRes = restTemplate.exchange(uri, HttpMethod.PUT,
                                                                new HttpEntity<String>(createHeaders(authorization)), String.class);

                                System.out.println("BPM call successful!!");
                                return startProcessRes;
                }
                
                
                public ResponseEntity<String> completeTask(HttpHeaders headers, String taskId, String payload) {

                                ResponseEntity<String> startProcessRes = null;

                                final String authorization = headers.get("Authorization").get(0);

                                
                                Map<String, String> pathVar = new HashMap<String, String>();
                                pathVar.put("taskId", taskId);
                                
                                UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(Constants.COMPLETE_TASK);
                                String uri = builder.buildAndExpand(pathVar).toUri().toString()+ "{" + payload + "}";
                                System.out.println("URI for complete task "+uri);
                                RestTemplate restTemplate = new RestTemplate();
                                System.out.println("Complete task .... ");
                                startProcessRes = restTemplate.exchange(uri, HttpMethod.PUT,
                                                                new HttpEntity<String>(createHeaders(authorization)), String.class);

                                System.out.println("BPM call successful!!");
                                return startProcessRes;
                }
                
                public ResponseEntity<String> reassignTask(HttpHeaders headers, String taskId,String userId, String payload) {

                	ResponseEntity<String> startProcessRes = null;

                    final String authorization = headers.get("Authorization").get(0);
                    
                    Map<String, String> pathVar = new HashMap<String, String>();
                    pathVar.put("taskId", taskId);
                    pathVar.put("userId", userId);
                    UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(Constants.REASSIGN_TASK);
                    URI uri = builder.buildAndExpand(pathVar).toUri();
                    System.out.println("Reassign URI"+uri);
                    RestTemplate restTemplate = new RestTemplate();
                    System.out.println("Reassigning Task .... ");
                    startProcessRes = restTemplate.exchange(uri, HttpMethod.PUT,
                                                    new HttpEntity<String>(createHeaders(authorization)), String.class);

                    System.out.println("BPM call successful!!");
                    return startProcessRes;
    }
                
                public ResponseEntity<String> getTaskDetails(HttpHeaders headers, String instanceId) {

                    ResponseEntity<String> startProcessRes = null;

                    final String authorization = headers.get("Authorization").get(0);
                    
                    Map<String, String> pathVar = new HashMap<String, String>();
                    pathVar.put("instanceId", instanceId);
                    UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(Constants.TASK_DETAILS);
                    URI uri = builder.buildAndExpand(pathVar).toUri();
                    RestTemplate restTemplate = new RestTemplate();
                    System.out.println("Getting Task Details.... ");
                    startProcessRes = restTemplate.exchange(uri, HttpMethod.GET,
                                                    new HttpEntity<String>(createHeaders(authorization)), String.class);

                    System.out.println("BPM call successful!!");
                    return startProcessRes;
    }
}
