package com.handler.dbaccess;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;



@RestController
public class TaskDetailsComponentController {
                
	 @Autowired
     TaskDetailsRepository taskDetailsRepository;
     
     @GetMapping("/task-details")
     public List<TaskDetails> getTaskDetails() {
     	return taskDetailsRepository.findAll();
     }                
     @PostMapping("/task-details/create/taskData")
     public void createTaskDetails(@RequestBody TaskDetails taskDetails) {
     	taskDetailsRepository.save(taskDetails);
     }
     @RequestMapping(value = "/api/task-details/search/{taskName}", method = RequestMethod.GET)
     public TaskDetails searchTaskDeails( @PathVariable("taskName") String taskName) {
     	return taskDetailsRepository.findByTaskName(taskName);
     }   


}
