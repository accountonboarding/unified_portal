package com.bpm.rest.webservices.restfulwebservices;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

public interface TaskDetailsRepository extends JpaRepository<TaskDetails, Long> {
	
	TaskDetails findByTaskName(String taskName);
}
