package com.bpm.rest.webservices.restfulwebservices;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;


/**
* @author rxhussa
* @date 07/12/2019
*/

@CrossOrigin
@RestController

public class BPMServiceController {  

                @Autowired
                private BPMWrapperService bpmWrapperService;
                
                
                @RequestMapping(value = { "/tasks/{processApp}",
                                                "/tasks/{processApp}/{interaction}" }, method = RequestMethod.PUT, consumes = { "application/JSON" })

                public ResponseEntity<String> getBPMTasksForProcessApp(@RequestHeader HttpHeaders headers,
                                                @PathVariable("processApp") String processApp, @PathVariable Optional<String> interaction) {

                                return bpmWrapperService.getBPMTasksForProcessApp(headers, processApp, interaction);

                }
                
                
                @RequestMapping(value = "/all-active-tasks", method = RequestMethod.POST, consumes = { "application/JSON" })

                public ResponseEntity<String> getAllActiveTasks(@RequestHeader HttpHeaders headers) {

                                return bpmWrapperService.getAllActiveTasks(headers);
                }

                @RequestMapping(value = "/current-user-details", method = RequestMethod.GET)

                public ResponseEntity<String> getUserDetails(@RequestHeader HttpHeaders headers) {

                                return bpmWrapperService.getUserDetails(headers);

                }

                @RequestMapping(value = "/start-onboarding-process", method = RequestMethod.POST, consumes = { "application/JSON" })

                public ResponseEntity<String> startOnboardingProcess(@RequestHeader HttpHeaders headers,
                                                @RequestBody String payload) {

                                return bpmWrapperService.startOnboardingProcess(headers, payload);

                }
                
                @RequestMapping(value = "/claim-task/{taskId}", method = RequestMethod.PUT)

                public ResponseEntity<String> claimTask(@RequestHeader HttpHeaders headers,
                                                @PathVariable("taskId") String taskId) {

                                return bpmWrapperService.claimTask(headers, taskId);

                }
                
               
                @RequestMapping(value = "/complete-task/{taskId}", method = RequestMethod.POST, consumes = { "application/JSON" })

                public ResponseEntity<String> completeTask(@RequestHeader HttpHeaders headers, @PathVariable("taskId") String taskId,
                                                @RequestBody String payload) {

                                return bpmWrapperService.completeTask(headers, taskId, payload);

                }
                
                @RequestMapping(value = "/reassign-task/{taskId}/{userId}", method = RequestMethod.PUT, consumes = { "application/JSON" })

                public ResponseEntity<String> reassignTask(@RequestHeader HttpHeaders headers, @PathVariable("taskId") String taskId,@PathVariable("userId") String userId,
                                                @RequestBody String payload) {
                				System.out.println("Reassigning Task Running=="+taskId+" :: "+userId);
                                return bpmWrapperService.reassignTask(headers, taskId,userId, payload);

                }
                @RequestMapping(value = "/task-summary/{instanceId}", method = RequestMethod.GET)

                public ResponseEntity<String> getTaskDetails(@RequestHeader HttpHeaders headers,
                                                @PathVariable("instanceId") String instanceId) {

                                return bpmWrapperService.getTaskDetails(headers, instanceId);

                }
                
                
                @Autowired
                TaskDetailsRepository taskDetailsRepository;
                
                @GetMapping("/task-details")
                public List<TaskDetails> getTaskDetails() {
                	return taskDetailsRepository.findAll();
                }                
                @PostMapping("/task-details/create/taskData")
                public void createTaskDetails(@RequestBody TaskDetails taskDetails) {
                	taskDetailsRepository.save(taskDetails);
                }
                @RequestMapping(value = "/api/task-details/search/{taskName}", method = RequestMethod.GET)
                public TaskDetails searchTaskDeails( @PathVariable("taskName") String taskName) {
                	return taskDetailsRepository.findByTaskName(taskName);
                }

}

