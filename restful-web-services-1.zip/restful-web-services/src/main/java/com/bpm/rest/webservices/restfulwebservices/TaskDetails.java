package com.bpm.rest.webservices.restfulwebservices;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "taskdetails", schema = "CCCDB")
public class TaskDetails{

    @Id
    private Long id;
    @Column(name = "task_name")
    private String taskName;
    @Column(name = "task_component")
    private String taskComponent;    

    public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	
	public TaskDetails(long id, String taskName, String taskComponent) {
        this.taskName = taskName;
        this.taskComponent = taskComponent;
        this.id = id;
    }
    
    public TaskDetails() {}

	public String getTaskName() {
		return taskName;
	}

	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}

	public String getTaskComponent() {
		return taskComponent;
	}

	public void setTaskComponent(String taskComponent) {
		this.taskComponent = taskComponent;
	}


   
}