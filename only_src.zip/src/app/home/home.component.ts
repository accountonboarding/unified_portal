import { Component, OnInit, Input } from '@angular/core';
import { first } from 'rxjs/operators';
import { BpmservicesService } from '../services/bpmservices.service';
import { User } from '../models/user.model';
import { Task } from '../models/task.model';
import { InboxTask } from '../models/inboxTask.model';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
 // loading = false;
 // user: User;
 taskList: InboxTask[];
 @Input() accountDetails = true;

  constructor(private bpmservice:BpmservicesService,private router:Router) { }

  ngOnInit() {
    //this.loading = true;
        // this.bpmservice.getCurrentUser().pipe(first()).subscribe(user => {
        //     this.loading = false;
        //    // this.user = user;
        // });
       this.startAccountOnboarding();
  }

  retrieveTasks(){
    
    this.router.navigate(["inbox"]);
    
  }
  startAccountOnboarding(){
    this.bpmservice.startAccountOnboarding().subscribe(data => {
      console.log("Account Onboarding started "+data.data.piid);
      alert("Process Id "+data.data.piid+" created");
      this.retrieveTasks();
    })
  }

}
