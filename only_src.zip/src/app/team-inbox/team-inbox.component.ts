import { Task } from '../models/task.model';
import {Component, OnInit, ViewChild, EventEmitter, Input} from '@angular/core';
import { MatPaginator } from '@angular/material';
import {MatTableDataSource} from '@angular/material/table'; 
import { MatSort } from '@angular/material/sort';
import { HttpHeaders } from '@angular/common/http';
import { HttpClient } from '@angular/common/http';
import { BpmservicesService } from '../services/bpmservices.service';
import { InboxTask } from '../models/inboxTask.model';
import { DatePipe } from '@angular/common';
import { MatDialog } from '@angular/material';
import { ReassignComponent } from '../reassign/reassign.component';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-team-inbox',
  templateUrl: './team-inbox.component.html',
  styleUrls: ['./team-inbox.component.css']
})
export class TeamInboxComponent implements OnInit {

  taskList: InboxTask[];
  
  taskCount: number;
  // public message = "";
  //loadTask: boolean;
  show:boolean = false;
  showInstanceDetails:boolean = false;
  @Input() showInput: boolean;
  @Input() flag: boolean;
  messageToSendP1: string = '';
  instanceIdSent: string = '';
  

  isTaskName = new EventEmitter();
  taskName: String;
  $selectedTask = new EventEmitter();

  constructor(private http:HttpClient,private bpmservice:BpmservicesService,public reassignDialog: MatDialog,private router:Router) { }
   displayedColumns: string[] = [ 'instanceId','taskSubject', 'dueDate', 'taskStatus', 'instanceName','accountNumber','accountType','action'];
  dataSource = new MatTableDataSource<InboxTask>(this.taskList);
  @ViewChild(MatPaginator, {static: false}) paginator: MatPaginator;
  @ViewChild(MatSort, {static: false}) sort: MatSort;
  ngOnInit() {
      this.retrieveTeamTasks();  
      // this.dataSource.paginator = this.paginator;
      // this.dataSource.sort = this.sort;
      var loadTask : boolean;

  }

  toggle(taskSubject: any){
    this.show = true;
    this.messageToSendP1 = taskSubject;
    
  }
  toggle2(showInput){
    this.show = showInput;
  }

  toggle3(flag){
    
      this.show = false;
      this.showInstanceDetails = false;
     
     // retrieveTaskHistory(element.instanceId);
   
  }
  clickTaskHistory(workitemID: any){
    console.log('abccccccccc' + workitemID);
    this.instanceIdSent = workitemID;

    console.log('abccccccccc 2 ' + this.instanceIdSent);
    this.show = false;
    this.showInstanceDetails = true;
  }

  retrieveTeamTasks(){
    var userName = localStorage.getItem('userName');
    var pipe = new DatePipe('en-US');
    if(userName){
      this.bpmservice.retrieveTasks().subscribe(
        data => {
            this.taskList = data.data.items;
            var len = this.taskList.length;
            console.log("team inbox task count "+len);
            this.taskCount = len;
            for(var i=0;i<len;i++){
                this.taskList[i].dueDate  =pipe.transform(this.taskList[i].dueDate, 'MM/dd/yyyy');
                this.taskList[i].taskSubject = this.taskList[i].taskSubject.substring(6);
                this.taskList[i].instanceName = this.taskList[i].instanceName.substring(0,this.taskList[i].instanceName.indexOf(':'));

                
            }
            this.dataSource = new MatTableDataSource<InboxTask>(this.taskList);
            this.dataSource.paginator = this.paginator;
            this.dataSource.sort = this.sort;
        
        }
      )
    }
  }

  // openDynamicComponent(taskId:any){
  //   //  this.loadTask = true;

  //     for(var i=0;i<this.taskList.length;i++){
  //         if(this.taskList[i].taskId == taskId){
  //           console.log("taskSubject is "+this.taskList[i].taskSubject);
  //           this.$selectedTask.emit(this.taskList[i]);
  //         }
  //     }
  //     this.router.navigate(["accountInformation"]);
  // }

  openReassignDialog(taskId:any){
      let dialogRef = this.reassignDialog.open(ReassignComponent, {data : {validUsers : [{name:'pratik.mondal@cognizant.com'},{name:'ctsibmbpmoncloud@gmail.com'}]}});

      dialogRef.afterClosed().subscribe(result => {
          console.log('Reassign dialog result :'+result);
          console.log('taskId '+taskId);
          this.bpmservice.reassignTask(taskId,result).subscribe(data => {
              console.log('reassign result '+data);
          }

          )

      });

     // dialogRef.afterClosed().
  }

  

}
