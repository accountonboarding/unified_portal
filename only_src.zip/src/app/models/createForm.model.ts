export interface CreateForm {
    firstName: string;
    lastName: string;
    gender: string;
    email: string;
    message: string;
    accountType: string;
   
}