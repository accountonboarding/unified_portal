export interface InboxTask {
    assignedToRole: string;
    assignedToUser: string;
    taskSubject: string;
    instanceId: string;
    instanceName: string;
    taskId: string;
    dueDate: string;
    taskStatus: string;
    action: string;
}