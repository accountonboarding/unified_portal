export interface InstanceDetailsTask {



    activationTime: string;
    assignedTo: string;
    assignedToDisplayName: string;
    assignedToType: string;
    completionTime: string;
    dueTime: string;
    name: string;
    isAtRisk: boolean;
    status: string;
    tkiid: string;


    

}