export interface Task {
    onboardingId: string;
    taskSubject: string;
    dueDate: string;
    status: string;
    action: string;
}