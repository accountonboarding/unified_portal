export interface AccountInformationTask {
    position: number;
    accountNumber: string;
    accountHolderName: string;
    branchName: string;

}