import { Component, OnInit, ViewContainerRef, ViewChild,  ComponentFactoryResolver, ComponentFactory, Input,Output, EventEmitter} from '@angular/core';
import { AccountInformationComponent } from '../account-information/account-information.component';
import { AccountDetailsComponent } from '../account-details/account-details.component';
import { BpmservicesService } from '../services/bpmservices.service';
import { Router } from '@angular/router';

import { InboxTask } from '../models/inboxTask.model';
//import { String, StringBuilder } from 'typescript-string-operations';



@Component({
  selector: 'app-dynamic-component',
  templateUrl: './dynamic-component.component.html',
  styleUrls: ['./dynamic-component.component.css']
})
export class DynamicComponentComponent implements OnInit{

  @Input() task: InboxTask;

  @ViewChild('entry', {read : ViewContainerRef,static : true}) entry: ViewContainerRef;
  taskName: String;
  taskId: String;
  public componentName: string;

  public show:boolean = false;
  @Output() public childEvent = new EventEmitter();
  @Input() receivedParentMessageInDynamicFromGeneric: string;

  
  constructor(
  private resolver: ComponentFactoryResolver,private bpmService: BpmservicesService,private router:Router) { }
   
  ngOnInit() {
    
   console.log("In dynamic component"+this.receivedParentMessageInDynamicFromGeneric);
   //var receivedMessage = this.receivedParentMessage;
   this.taskName = this.receivedParentMessageInDynamicFromGeneric.split(":")[0];
   this.taskId = this.receivedParentMessageInDynamicFromGeneric.split(":")[1];

   console.log("task name after split"+this.taskName);
   this.bpmService.getComponentName(this.taskName).subscribe(data => {
              this.componentName = data.taskComponent;
              console.log('component name '+this.componentName);
              const compMap = {
               'doc_checklist': AccountInformationComponent,
               'account_details': AccountDetailsComponent
              };
              if (this.componentName in compMap) {
                  console.log("in account details");
                  const componentFactory = this.resolver.resolveComponentFactory(compMap[this.componentName]);
                  
                  const component = this.entry.createComponent(componentFactory);
                  
              } else {
                  console.log(" not in account details");
              }
          });
    }
  
  submitComponent(){

    this.router.navigate(["inbox"]);
  }

  fireEvent(){
    this.show = true;
    this.childEvent.emit(this.show);
  }
  completeTask(){
    console.log("complete task"+this.taskId);
    this.bpmService.completeTask(this.taskId).subscribe( data => {
      console.log("Task completed ");
      this.fireEvent();
    })
  }
  showDynamicContent(){
    var x = document.getElementById("dynamicContent");
    
    if (x.style.display === "none") {
      x.style.display = "block";
    } else {
      x.style.display = "none";
    }

  }


}