import { Component, OnInit, Input, Output, EventEmitter, ViewChild} from '@angular/core';
import { Router } from '@angular/router';
import {  AccountInformationTask } from '../models/account-Information.model';
import { MatPaginator, MatTableDataSource } from '@angular/material';


const ELEMENT_DATA: AccountInformationTask[] = [
  {position: 9, accountNumber: '938000908', accountHolderName: 'Pradyuman', branchName: 'Mumbai'},
  {position: 1, accountNumber: '938000900', accountHolderName: 'Dr. Salukiya', branchName: 'Kolkata'},
  {position: 2, accountNumber: '938000901', accountHolderName: 'Daya', branchName: 'Chennai'},
  {position: 1, accountNumber: '938000900', accountHolderName: 'Abhijeet', branchName: 'Kolkata'},
  {position: 3, accountNumber: '938000902', accountHolderName: 'Fedrick', branchName: 'Delhi'},
  {position: 4, accountNumber: '938000903', accountHolderName: 'Vivek', branchName: 'Jorhat'},
  {position: 5, accountNumber: '938000904', accountHolderName: 'John', branchName: 'Mumbai'},
  {position: 6, accountNumber: '938000905', accountHolderName: 'Meena', branchName: 'Ranchi'},
  {position: 7, accountNumber: '938000906', accountHolderName: 'Kartik', branchName: 'Mumbai'},
  {position: 8, accountNumber: '938000907', accountHolderName: 'Karishma', branchName: 'Mumbai'},
  {position: 9, accountNumber: '938000908', accountHolderName: 'Sweta', branchName: 'Mumbai'},
  {position: 10, accountNumber: '938000909', accountHolderName: 'Geeta', branchName: 'Mumbai'},
];


@Component({
  selector: 'app-account-information',
  templateUrl: './account-information.component.html',
  styleUrls: ['./account-information.component.css']
})
export class AccountInformationComponent implements OnInit {
  

  public show:boolean = false;
  @Output() public childEvent = new EventEmitter();

  displayedColumns: string[] = ['position', 'accountNumber', 'accountHolderName', 'branchName'];
  dataSource = new MatTableDataSource<AccountInformationTask>(ELEMENT_DATA);
  // dataSource = ELEMENT_DATA;


  constructor(private router:Router) { }
  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;
  ngOnInit() {
    this.dataSource.paginator = this.paginator;
  }
 
  fireEvent(){
 
      this.show = true;
      this.childEvent.emit(this.show);
  }


}
