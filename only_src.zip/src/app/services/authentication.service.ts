import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { User } from '../models/user.model';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {

  authorizationData:any;
 // public currentUser: Observable<User>;

  constructor(private http: HttpClient) { 
    
  }

  login(username: string, password: string) :Boolean {

    if(username == 'ctsibmbpmoncloud@gmail.com' && password == 'Bpmoncloud@8'){
      this.authorizationData = btoa(username + ':' + password);
      localStorage.setItem("authToken",this.authorizationData);
      localStorage.setItem("loggedInUserName", username);
      return true;
    }else{
      return false;
    }
        /*return this.http.post<any>(`${environment.apiUrl}/users/authenticate`, { username, password })
            .pipe(map(user => {
                // store user details and basic auth credentials in local storage to keep user logged in between page refreshes
                user.authdata = window.btoa(username + ':' + password);
                localStorage.setItem('currentUser', JSON.stringify(user));
                this.currentUserSubject.next(user);
                return user;
            }));*/
           
    }

    logout() {
        // remove user from local storage to log user out
        localStorage.removeItem('authToken');
       // this.currentUserSubject.next(null);
    }
}
