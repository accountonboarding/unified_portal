import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { User } from '../models/user.model';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class BpmservicesService {

  constructor(private http: HttpClient) { }

  getCurrentUser() : Observable<any> {
       // return this.http.get('http://10.243.185.103:8080/current-user-details').pipe();
       console.log("in getCurrentUser");
        return this.http.get('http://10.107.10.194:8080/current-user-details').pipe();
    //     subscribe(
    //     data => { // json data
    //         console.log('Success: ', data);
    //         JSON.parse(JSON.stringify(data),(key,value) =>{
    //           if (typeof value === 'string') {
    //              // console.log('Success 1: ', value);
    //              }
    //           });
            
    //     },
    //     error => {
    //         console.log('Error: ', error);
    //     });

    //   return this.user;  
    // }
  }

  retrieveTasks() : Observable<any> {
    return this.http.put('http://10.107.10.194:8080/tasks/ACCTONB/available',{processApp:'ACCTONB'}).pipe();
  }
  retrieveMyTasks() : Observable<any> {
    return this.http.put('http://10.107.10.194:8080/tasks/ACCTONB/claimed',{processApp:'ACCTONB'}).pipe();
  }

  getValidUsers() : Observable<any> {
    return this.http.put('http://10.243.185.103:8080/tasks/ACCTONB',{processApp:'ACCTONB'}).pipe();
  }

  reassignTask(tskId,usrId) : Observable<any> {
    console.log('usr Id in bpm service'+ usrId);
    usrId +='.junk';
    return this.http.put('http://10.107.10.194:8080/reassign-task/'+tskId+'/'+usrId,{taskId:tskId,userId:usrId}).pipe();
  }
  getComponentName(taskName) : Observable<any> {
    //return this.http.get('http://10.107.10.194:8080/task-details/search/'+taskName).pipe();
    return this.http.get('/api/task-details/search/'+taskName).pipe();
  }
  retrieveTaskHistory(instanceId) : Observable<any> {
    return this.http.get('http://10.107.10.194:8080/task-summary/'+instanceId).pipe();
  }
  claimTask(taskId) : Observable<any> {
    return this.http.put('http://10.107.10.194:8080/claim-task/'+taskId,{taskId:taskId}).pipe();
  }
  completeTask(taskId) : Observable<any> {
    return this.http.post('http://10.107.10.194:8080/complete-task/'+taskId,{taskId:taskId}).pipe();
  } 
  startAccountOnboarding() : Observable<any> {
    return this.http.post('http://10.107.10.194:8080/start-onboarding-process/',{}).pipe();
  }
    
}
