import { TestBed } from '@angular/core/testing';

import { BpmservicesService } from './bpmservices.service';

describe('BpmservicesService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: BpmservicesService = TestBed.get(BpmservicesService);
    expect(service).toBeTruthy();
  });
});
