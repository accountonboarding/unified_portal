// import { Injectable } from '@angular/core';
// import { BehaviorSubject } from 'rxjs';

// @Injectable({
//   providedIn: 'root'
// })
// export class DatashareService {
//   taskName: BehaviorSubject<String>;
//   localTaskName: String;

//   constructor() { 
//    // this.taskName = new BehaviorSubject(this.localTaskName);
//   }

//   setTaskNameValue(taskName: String){
//    // this.taskName = taskName;
//   }
// }
