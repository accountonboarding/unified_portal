import { Component, OnInit, Output, EventEmitter, Input, ComponentFactoryResolver, ViewChild, ViewContainerRef } from '@angular/core';
import { BpmservicesService } from '../services/bpmservices.service';
import { AccountInformationComponent } from '../account-information/account-information.component';
import { AccountDetailsComponent } from '../account-details/account-details.component';

@Component({
  selector: 'app-generic-screen',
  templateUrl: './generic-screen.component.html',
  styleUrls: ['./generic-screen.component.css']
})
export class GenericScreenComponent implements OnInit {


  public show:boolean = false;
  @Output() public childEvent = new EventEmitter();
  @Input() receivedParentMessage: string;
  // @ViewChild('entry', {read : ViewContainerRef,static : true}) entry: ViewContainerRef;
  taskName: String;
  taskId: String;
  instanceId: String;
  messageTomessageToSendInstanceDetails: string = '';
  messageToSendDynamic: string = '';
  // public componentName: string;

  constructor(private  resolver: ComponentFactoryResolver, private bpmService: BpmservicesService) {}
  // constructor() {}

  ngOnInit() {
    
   console.log("In dynamic component"+this.receivedParentMessage);
   var receivedMessage = this.receivedParentMessage;
   this.taskName = this.receivedParentMessage.split(":")[0];
   this.taskId = this.receivedParentMessage.split(":")[1];
   this.instanceId = this.receivedParentMessage.split(":")[2];
   this.messageTomessageToSendInstanceDetails = this.receivedParentMessage;
   this.messageToSendDynamic = this.receivedParentMessage;
    // this.bpmService.claimTask(this.taskId).subscribe(data => {
    //                 console.log("claim task data "+ data.data.displayName);
    //               })
  //  document.getElementById("defaultOpen").click();
  //  console.log("task name after split"+this.taskName);
  //  this.bpmService.getComponentName(this.taskName).subscribe(data => {
  //             this.componentName = data.taskComponent;
  //             console.log('component name '+this.componentName);
  //             const compMap = {
  //              'doc_checklist': AccountInformationComponent,
  //              'account_details': AccountDetailsComponent
  //             };
  //             if (this.componentName in compMap) {
  //                 console.log("in account details");
  //                 const componentFactory = this.resolver.resolveComponentFactory(compMap[this.componentName]);
  //                 const component = this.entry.createComponent(componentFactory);
  //                 this.bpmService.claimTask(this.taskId).subscribe(data => {
  //                   console.log("claim task data "+ data.data.displayName);
  //                 })
  //             } else {
  //                 console.log(" not in account details");
  //             }
  //         });
    }

    //  openCity(evt, cityName) {
    //   // Declare all variables
    //   var i: number, tabcontent, tablinks;
    
    //   // Get all elements with class="tabcontent" and hide them
    //   tabcontent = document.getElementsByClassName("tabcontent");
    //   for (i = 0; i < tabcontent.length; i++) {
    //     tabcontent[i].style.display = "none";
    //   }
    
    //   // Get all elements with class="tablinks" and remove the class "active"
    //   tablinks = document.getElementsByClassName("tablinks");
    //   for (i = 0; i < tablinks.length; i++) {
    //     tablinks[i].className = tablinks[i].className.replace(" active", "");
    //   }
    
    //   // Show the current tab, and add an "active" class to the button that opened the tab
    //   // document.getElementById(cityName).style.display = "block";
    //   // evt.currentTarget.className += " active";
    // }

  fireEvent(){
    this.show = true;
    this.childEvent.emit(this.show);
  }
  completeTask(){
    console.log("complete task"+this.taskId);
    this.bpmService.completeTask(this.taskId).subscribe( data => {
      console.log("Task completed ");
      this.fireEvent();
    })
  }


   openPage(pageName, elmnt, color) {
    // Hide all elements with class="tabcontent" by default */
    // debugger;
    var i, tabcontent, tablinks;
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
      tabcontent[i].style.display = "none";
    }
  
    // Remove the background color of all tablinks/buttons
    tablinks = document.getElementsByClassName("tablink");
    for (i = 0; i < tablinks.length; i++) {
      tablinks[i].style.backgroundColor = "";
    }
  
    // Show the specific tab content
    document.getElementById(pageName).style.display = "block";
  
    // Add the specific color to the button used to open the tab content
    elmnt.style.backgroundColor = color;
  }
  
  // Get the element with id="defaultOpen" and click on it

  //  document.getElementById("defaultOpen").click();

}
