import { Component, OnInit } from '@angular/core';
import { BpmservicesService } from '../services/bpmservices.service';
import { Router } from '@angular/router';
import {CreateForm} from '../models/createForm.model';

@Component({
  selector: 'app-create-instance-form',
  templateUrl: './create-instance-form.component.html',
  styleUrls: ['./create-instance-form.component.css']
})
export class CreateInstanceFormComponent implements OnInit {

  instanceId: string = '';
  showProcessId: boolean;
  showForm: boolean;
  model: CreateForm;
  fname: string = '';
  lname: string = '';

  constructor(private bpmservice:BpmservicesService, private router:Router) { }

  // model = new CreateForm('a','b','c','d','e','f');
  

  ngOnInit() {
    this.showProcessId = false;
    this.showForm = true;
    // this.model.firstName = '';
  }
  retrieveTasks(){
    // alert("go to header");
    this.showProcessId = false;
    this.showForm = true;
    this.fname = "";
    // this.router.navigate(["header"]);
    
  }


  startAccountOnboarding(){
    if(this.fname == ""){
      alert("Fill in mandatory fields");
      this.showProcessId = false;
      this.showForm = true;
      
    }else{
      this.bpmservice.startAccountOnboarding().subscribe(data => {
        console.log("Account Onboarding started "+data.data.piid);
        // alert("Process Id "+data.data.piid+" created");

          this.instanceId ="Process Id "+data.data.piid+" created";
      
          // this.retrieveTasks();
          this.showProcessId = true;
          this.showForm = false;
        //  }


      })
    }

  }
}
