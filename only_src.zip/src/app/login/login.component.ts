import { Component, OnInit, Input } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { HttpHeaders } from '@angular/common/http';
import { HttpClient } from '@angular/common/http';
import { AuthenticationService } from '../services/authentication.service';
import { BpmservicesService } from '../services/bpmservices.service';
import { first } from 'rxjs/operators';

let authorizationData;// = 'Basic ' + btoa('ctsibmbpmoncloud@gmail.com' + ':' + 'Bpmoncloud@8');
let httpOptions;
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})

export class LoginComponent implements OnInit {

  username: string;
  password: string;
  loading = false;
  error: any;
// accountDetails = false;
 messageToSendP2: boolean; 
    
  constructor(private router:Router,private http:HttpClient,private authenticationService: AuthenticationService, private bpmService : BpmservicesService) { }


  ngOnInit() {
     this.messageToSendP2 = false; 
  }

  // login() : void {
  //   if(this.username == 'admin' && this.password == 'admin'){
  //     authorizationData = 'Basic ' + btoa('ctsibmbpmoncloud@gmail.com' + ':' + 'Bpmoncloud@6');
  //     httpOptions = {
  //        headers: new HttpHeaders({
  //                   'Content-Type':  'application/json',
  //                   'Authorization': authorizationData
  //     })
  //   };

  //  // if(this.Auth.authenticate(this.username,this.password)){
  //    this.http.get('http://10.243.185.103:8080/current-user-details', httpOptions )
  //   .subscribe(
  //       data => { // json data
  //           console.log('Success: ', data);
            
  //       },
  //       error => {
  //           console.log('Error: ', error);
  //       });
  //    /* this.http.put('http://10.243.185.103:8080/tasks/ACCTONB',httpOptions).subscribe(
  //       data => { // json data
  //           console.log('Success: ', data);
  //       },
  //       error => {
  //           console.log('Error: ', error);
  //       });*/
  //       localStorage.setItem("authToken",authorizationData);
  //    console.log('auth data 1'+localStorage.getItem("authToken"));

  //    //this.router.navigate(["inbox"]);
  //   }else {
  //     alert("Invalid credentials");
  //   }
  // }


  onSubmit() {
        

        this.loading = true;
//console.log('Hello Sujit');
        var validUser = this.authenticationService.login(this.username, this.password);            
            
        // var authorizationData = 'Basic ' + btoa('ctsibmbpmoncloud@gmail.com' + ':' + 'Bpmoncloud@6');
        if (validUser){
            this.bpmService.getCurrentUser().subscribe(
              data => { // json data
                  console.log('Success: ', data);
                  JSON.parse(JSON.stringify(data),(key,value) =>{
                    if (typeof value === 'string') {
                      if (key === 'fullName'){
                        localStorage.setItem('userName',value);
                        //console.log('Success 1: ', value);
                        this.router.navigate(["header"]);
                      }
                      // console.log('Success 1: ', value);
                      }
                    });
                  
              },
              error => {
                  console.log('Error: ', error);
              }
            )
        }else {
          alert("Invalid credentials");
        }
      
    }

}
