import { BrowserModule } from '@angular/platform-browser';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { Routes, RouterModule } from '@angular/router';
import { ConsolidatedMaterialModules } from './core/material.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { BasicAuthInterceptor } from './helpers/basic-auth.interceptor';
import { FlexLayoutModule } from "@angular/flex-layout";



//import {AuthService } from './auth.service';
//import { Store, StoreModule } from '@ngrx/store';

import { HttpClientModule, HTTP_INTERCEPTORS  } from '@angular/common/http';
import { InboxComponent } from './inbox/inbox.component';
import { HomeComponent } from './home/home.component';
import { HeaderComponent } from './header/header.component';
import { ReassignComponent } from './reassign/reassign.component';
import { AccountDetailsComponent } from './account-details/account-details.component';
import { DynamicComponentComponent } from './dynamic-component/dynamic-component.component';
import { AccountInformationComponent } from './account-information/account-information.component';
import { InstanceDetailsComponent } from './instance-details/instance-details.component';
import { ReportsComponent } from './reports/reports.component';
import { TasksComponent } from './tasks/tasks.component';
import { CommentComponent } from './comment/comment.component';
import { AuditTrailComponent } from './audit-trail/audit-trail.component';
import { GenericScreenComponent } from './generic-screen/generic-screen.component';
import { TaskHistoryComponent } from './task-history/task-history.component';
import { CreateInstanceFormComponent } from './create-instance-form/create-instance-form.component';
import { TeamInboxComponent } from './team-inbox/team-inbox.component';
// import { MatPaginatorModule } from '@angular/material';
// import {MatPaginatorModule} from '@angular/material'; 


const routes: Routes = [
  {path:'', redirectTo:'/login',pathMatch:'full'},
  {path:'login', component:LoginComponent},
  {path:'inbox', component:InboxComponent},
  {path:'tasks', component:TasksComponent},
  {path:'home', component:HomeComponent},
  {path:'header', component:HeaderComponent},
  {path:'dynamic', component: DynamicComponentComponent},
  {path:'reports', component: ReportsComponent},
  {path:'accountInformation', component: AccountInformationComponent},
  {path:'instance-details', component:InstanceDetailsComponent},
  {path:'create-instance-form', component:CreateInstanceFormComponent},
  {path:'team-inbox', component:TeamInboxComponent}
  
];

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    InboxComponent,
    HomeComponent,
    HeaderComponent,
    ReassignComponent,
    AccountDetailsComponent,
    DynamicComponentComponent,
    AccountInformationComponent,
    InstanceDetailsComponent,
    ReportsComponent,
    TasksComponent,
    CommentComponent,
    AuditTrailComponent,
    GenericScreenComponent,
    TaskHistoryComponent,
    CreateInstanceFormComponent,
    TeamInboxComponent
    // MatPaginatorModule
    
  ],
  entryComponents : [
    ReassignComponent,
    AccountDetailsComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    ConsolidatedMaterialModules,
    HttpClientModule,
    FormsModule,
    AppRoutingModule,
    FlexLayoutModule,
   // StoreModule.forRoot({}),
    RouterModule.forRoot(routes)
    
  ],
  exports: [RouterModule],
 // providers: [AuthService,Store],
  providers: [{ provide: HTTP_INTERCEPTORS, useClass: BasicAuthInterceptor, multi: true }],
  bootstrap: [AppComponent]
})
export class AppModule { }
