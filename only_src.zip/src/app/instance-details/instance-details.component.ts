import { Component, OnInit,Input , Output, EventEmitter } from '@angular/core';
import { InstanceDetailsTask } from '../models/instance-details.model';
import { BpmservicesService } from '../services/bpmservices.service';
import { Router } from '@angular/router';
import { MatTableDataSource } from '@angular/material/table';
import { DatePipe } from '@angular/common';
// import { MatTableDataSource } from '@angular/material';

const ELEMENT_DATA: InstanceDetailsTask[] = [
  // {activationTime: '', assignedTo: '', assignedToDisplayName: '', assignedToType: '', completionTime: '', dueTime: '', name: '', isAtRisk: false, status: '', tkiid: '' },
  // {taskName: 'Task 2', taskId: 938000900 , receivedDate: '01/09/2020', completedDate: '01/09/2020' , completedBy: 'Dholu' },
  // {taskName: 'Task 3', taskId: 938000901 , receivedDate: '01/09/2020', completedDate: '01/09/2020' , completedBy: 'Kalu' },
  // {taskName: 'Task 4', taskId: 938000900 , receivedDate: '01/09/2020', completedDate: '01/09/2020' , completedBy: 'Buchu'},
 ];

@Component({
  selector: 'app-instance-details',
  templateUrl: './instance-details.component.html',
  styleUrls: ['./instance-details.component.css']
})
export class InstanceDetailsComponent implements OnInit {


  displayedColumns: string[] = ['name', 'tkiid', 'dueTime', 'completionTime', 'completedBy','activationTime', 'status', 'assignedToDisplayName'];
  // dataSource = ELEMENT_DATA;
  taskList: InstanceDetailsTask[];
  public show:boolean = false;
  public showInstance:boolean = false;
  public flag:boolean = false;
  @Output() public childEvent = new EventEmitter();
  // @Input() sendMessageToAppIns: string;
  @Input() public receivedParentMessage2: string;
  @Input() public receivedParentMessageFromGenericScreen: string;
  instanceDetails: InstanceDetailsTask[] ;
  taskNameInInstanceDetails: String;
  taskIdInInstanceDetails: String;
  instanceIdInInstanceDetails: String;
  panelOpenState = false;

  constructor(private router:Router, private bpmService: BpmservicesService) {

      // dataSource = new MatTableDataSource<InstanceDetailsTask>(this.instanceDetails);
   }
   dataSource = new MatTableDataSource<InstanceDetailsTask>(this.instanceDetails);
  ngOnInit() {

   // console.log('abcccccyyy77777');
    // this.retrieveTaskHistory(this.receivedParentMessage2);
    this.taskNameInInstanceDetails = this.receivedParentMessageFromGenericScreen.split(":")[0];
    this.taskIdInInstanceDetails = this.receivedParentMessageFromGenericScreen.split(":")[1];
    this.instanceIdInInstanceDetails = this.receivedParentMessageFromGenericScreen.split(":")[2];
   


  }

  showContent(){
    var x = document.getElementById("instanceDetailsContent");
    
    if (x.style.display === "none") {
      x.style.display = "block";
    } else {
      x.style.display = "none";
    }

  }

  returnBack(){
  // this.router.navigate(["inbox"]);
  // this.show = true;
  // this.showInstance = false;
  //   if(this.show == true && this.showInstance == false){
      this.flag = true;
      this.childEvent.emit(this.flag);
    // }
  }

  retrieveTaskHistory(instanceId:any){
    //this.router.navigate(["instance-details"]);
      this.bpmService.retrieveTaskHistory(instanceId).subscribe(
        data => {
                 
            // this.instanceDetails = data.data.tasks;
            // var len = this.instanceDetails.length;
            this.instanceDetails = data.data.tasks;
            var len = this.instanceDetails.length;
            var pipe = new DatePipe('en-US');
           // this.taskCount = len;
           //this.instanceDetails  = [ {taskName: 'Task 1', taskId: 938000908 , receivedDate: '01/09/2020', completedDate: '01/09/2020' , completedBy: 'Dipu', leng: 1}];
            for(var i=0;i<len;i++){
                var taskListLen = len-1;
                //this.instanceDetails.
                // console.log('check check'+ this.instanceDetails + len);
               // console.log('Task History : ' + taskHistory[i].name);
               // this.instanceDetails[i] = new InstanceDetailsTask();
              // var tempObj = new InstanceDetailsTask();
                //this.instanceDetails[i].taskName = taskHistory[i].name;
                console.log('Task History 2 : ' + this.instanceDetails[i].name);
    
                 this.instanceDetails[i].completionTime  =pipe.transform(this.instanceDetails[i].completionTime, 'MM/dd/yyyy');
                 this.instanceDetails[i].dueTime  =pipe.transform(this.instanceDetails[i].dueTime, 'MM/dd/yyyy');
                  var tempCompletedDate =  this.instanceDetails[i].completionTime;
                  if(tempCompletedDate){
                    this.instanceDetails[i].assignedTo = this.instanceDetails[i].assignedToDisplayName;
                    this.instanceDetails[i].assignedToDisplayName = '';
                  }else{
                    this.instanceDetails[i].assignedTo = '';
                  }
                    // this.taskList[i ] = this.instanceDetails[i];
                // name = this.instanceDetails[i].name;

                //this.instanceDetails[i].name = ;
              //  this.instanceDetails[i].dueDate  =pipe.transform(this.taskList[i].dueDate, 'MM/dd/yyyy');
              //  this.taskList[i].taskSubject = this.taskList[i].taskSubject.substring(6);
            }

            this.dataSource = new MatTableDataSource<InstanceDetailsTask>(this.instanceDetails);
            this.showInstance = true;
            this.show = false;

         
            //  console.log("instance history "+data.data.tasks[1].status);
            //  console.log("instance history length "+this.taskCount);
            

            //  console.log("instance history "+data.data.tasks[1].status);
            //  console.log("instance history length "+this.taskCount);
            
        
        }
       
      )
  }
}
