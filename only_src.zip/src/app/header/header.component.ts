import { Component, OnInit, Input } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { AuthenticationService } from '../services/authentication.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  @Input() accountDetails = true;
  userName: string= '';

  

  constructor(private router:Router,private authenticationService: AuthenticationService) { }

  ngOnInit() {
   // this.router.navigate(["inbox"]);

    // var accountDetails2 = localStorage.getItem("accountDetails");
       this.userName = localStorage.getItem('userName');
       console.log('LoggedInUserName ======>'+ this.userName);

  }

  retrieveTasks(){
     this.router.navigate(["inbox"]);
  }

  logout(){
    var validUser = this.authenticationService.logout();
    this.router.navigate(['login']);          
  }

}
