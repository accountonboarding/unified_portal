package com.example.demo;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "student", schema = "CCCDB")
public class Student{

    @Id
    private Long id;
    private String name;
    private String address;
   

    

    public Student(long id, String name, String address) {
        this.name = name;
        this.address = address;
        this.id = id;
    }
    
    public Student() {}

    @Override
    public String toString() {
      return String.format("Student[id=%d, name='%s',address='%s']", id,name,address);
    }
}