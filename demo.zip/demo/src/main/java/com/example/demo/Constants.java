package com.example.demo;

public final class Constants {

    public static final String USER_TASKS_FILETR = "https://vmiksa69901am4.us.bank-dns.com:9444/rest/bpm/wle/v1/tasks?calcStats=true";
    public static final String ALL_USER_TASKS = "https://vmiksa69901am4.us.bank-dns.com:9444/rest/bpm/wle/v1/service/4e36c23d-dca6-474a-9134-b4fe6145d836?action=start&accept=application/json";
    public static final String CURRENT_USER_DETAILS = "https://ebpm-it.us.bank-dns.com/rest/bpm/wle/v1/user/current?includeInternalMemberships=false&includeEditableUserPreferences=false&parts=all&accept=application/json";
    public static final String START_ONBOARDING_PROCESS = "https://vmiksa69901am4.us.bank-dns.com:9444/rest/bpm/wle/v1/process?action=start&bpdId=25.f55298ab-c656-40ba-87ed-9cd170e17960&branchId=2063.bfa38483-82c8-434d-9a87-9010d61b2599&params=";
    public static final String CLAIM_TASK = "https://vmiksa69901am4.us.bank-dns.com:9444/rest/bpm/wle/v1/task/{taskId}?action=assign&toMe=true&parts=all";
    public static final String COMPLETE_TASK = "https://vmiksa69901am4.us.bank-dns.com:9444/rest/bpm/wle/v1/task/{taskId}?action=complete&params=";

}


